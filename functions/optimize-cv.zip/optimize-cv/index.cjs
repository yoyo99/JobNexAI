"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// functions/optimize-cv/index.ts
var optimize_cv_exports = {};
__export(optimize_cv_exports, {
  default: () => handler
});
module.exports = __toCommonJS(optimize_cv_exports);
var import_openai = __toESM(require("openai"));
var import_supabase_js = require("@supabase/supabase-js");
var openai = new import_openai.default({
  apiKey: process.env.OPENAI_API_KEY
});
var supabase = (0, import_supabase_js.createClient)(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);
var corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type"
};
async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "authorization, x-client-info, apikey, content-type");
  if (req.method === "OPTIONS") {
    res.status(200).send("ok");
    return;
  }
  try {
    const { cv, jobDescription } = await req.json();
    const completion = await openai.chat.completions.create({
      model: "gpt-4",
      messages: [
        {
          role: "system",
          content: `Tu es un expert en recrutement et en optimisation de CV avec plus de 20 ans d'exp\xE9rience. 
          
          T\xC2CHE:
          Analyse le CV fourni et la description du poste pour sugg\xE9rer des am\xE9liorations sp\xE9cifiques et concr\xE8tes qui augmenteront significativement les chances du candidat d'\xEAtre retenu.
          
          INSTRUCTIONS D\xC9TAILL\xC9ES:
          1. Analyse la correspondance entre les comp\xE9tences du candidat et celles requises dans l'offre d'emploi
          2. Identifie les mots-cl\xE9s et comp\xE9tences manquants qui devraient \xEAtre ajout\xE9s au CV
          3. Sugg\xE8re des reformulations pour mettre en valeur les r\xE9alisations et l'impact du candidat
          4. Propose des modifications pour optimiser le CV pour les syst\xE8mes ATS (Applicant Tracking Systems)
          5. Identifie les \xE9l\xE9ments superflus ou contre-productifs \xE0 supprimer
          6. Sugg\xE8re une structure optimale pour le CV en fonction du poste vis\xE9
          
          FORMAT DE R\xC9PONSE:
          Fournis des suggestions pr\xE9cises et actionnables, organis\xE9es par section du CV.
          Pour chaque suggestion, explique pourquoi elle est importante et comment elle augmentera les chances du candidat.`
        },
        {
          role: "user",
          content: `CV:
${JSON.stringify(cv)}

Description du poste:
${jobDescription}`
        }
      ],
      temperature: 0.7,
      max_tokens: 1500
    });
    const suggestions = completion.choices[0].message.content;
    const keywordsCompletion = await openai.chat.completions.create({
      model: "gpt-4",
      messages: [
        {
          role: "system",
          content: `Tu es un expert en recrutement sp\xE9cialis\xE9 dans l'optimisation de CV pour les syst\xE8mes ATS (Applicant Tracking Systems).
          
          T\xC2CHE:
          Extrais les 15-20 mots-cl\xE9s les plus pertinents de la description du poste qui devraient absolument figurer dans le CV du candidat.
          
          INSTRUCTIONS:
          1. Identifie les comp\xE9tences techniques sp\xE9cifiques mentionn\xE9es
          2. Rep\xE8re les soft skills importants
          3. Note les outils, logiciels et technologies requis
          4. Identifie la terminologie sp\xE9cifique au secteur
          5. Rep\xE8re les qualifications, certifications ou dipl\xF4mes mentionn\xE9s
          
          FORMAT DE R\xC9PONSE:
          Fournis une liste num\xE9rot\xE9e des mots-cl\xE9s, class\xE9s par ordre d'importance.`
        },
        {
          role: "user",
          content: jobDescription
        }
      ],
      temperature: 0.5,
      max_tokens: 500
    });
    const keywords = keywordsCompletion.choices[0].message.content;
    return new Response(
      JSON.stringify({ suggestions, keywords }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 200
      }
    );
  } catch (error) {
    console.error("Error:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 400
      }
    );
  }
}
