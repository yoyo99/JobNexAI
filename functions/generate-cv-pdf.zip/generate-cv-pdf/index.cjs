"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// functions/generate-cv-pdf/index.ts
var generate_cv_pdf_exports = {};
__export(generate_cv_pdf_exports, {
  default: () => handler
});
module.exports = __toCommonJS(generate_cv_pdf_exports);
var import_supabase_js = require("@supabase/supabase-js");
var import_pdfmake = __toESM(require("pdfmake"));
var import_jsonwebtoken = __toESM(require("jsonwebtoken"));
var STANDARD_TEMPLATE_STYLE = {
  header: { fontSize: 24, bold: true, margin: [0, 0, 0, 10] },
  subheader: { fontSize: 18, margin: [0, 0, 0, 5] },
  sectionHeader: { fontSize: 14, bold: true, margin: [0, 15, 0, 10] },
  contact: { fontSize: 10, color: "#666666" }
};
var CREATIVE_TEMPLATE_STYLE = {
  header: { fontSize: 28, bold: true, color: "#2563eb", margin: [0, 0, 0, 10] },
  subheader: { fontSize: 20, color: "#4b5563", margin: [0, 0, 0, 5] },
  sectionHeader: { fontSize: 16, bold: true, color: "#2563eb", margin: [0, 20, 0, 10] },
  contact: { fontSize: 12, color: "#4b5563" }
};
var FREELANCE_TEMPLATE_STYLE = {
  header: { fontSize: 26, bold: true, color: "#059669", margin: [0, 0, 0, 10] },
  subheader: { fontSize: 19, color: "#374151", margin: [0, 0, 0, 5] },
  sectionHeader: { fontSize: 15, bold: true, color: "#059669", margin: [0, 20, 0, 10] },
  contact: { fontSize: 11, color: "#374151" }
};
function getTemplateStyle(category) {
  const styles = {
    standard: STANDARD_TEMPLATE_STYLE,
    creative: CREATIVE_TEMPLATE_STYLE,
    freelance: FREELANCE_TEMPLATE_STYLE
  };
  if (category in styles) {
    return { styles: styles[category] };
  } else {
    return { styles: styles.standard };
  }
}
function getSectionContent(section) {
  switch (section.type) {
    case "experience" /* EXPERIENCE */:
      return section.content.items.map((item) => ({
        stack: [
          { columns: [{ text: item.title, bold: true }, { text: item.date, alignment: "right" }] },
          { columns: [{ text: item.company }, { text: item.location, alignment: "right" }], margin: [0, 2] },
          { text: item.description, margin: [0, 5] }
        ],
        margin: [0, 0, 0, 10]
      }));
    case "education" /* EDUCATION */:
      return section.content.items.map((item) => ({
        stack: [
          { columns: [{ text: item.degree, bold: true }, { text: item.date, alignment: "right" }] },
          { columns: [{ text: item.school }, { text: item.location, alignment: "right" }], margin: [0, 2] }
        ],
        margin: [0, 0, 0, 10]
      }));
    case "skills" /* SKILLS */:
      return {
        columns: section.content.categories.map((category) => ({
          stack: [
            { text: category.name, bold: true, margin: [0, 0, 0, 5] },
            { ul: category.skills }
          ]
        }))
      };
    case "projects" /* PROJECTS */:
      return section.content.items.map((item) => ({
        stack: [
          { text: item.name, bold: true },
          { text: item.description, margin: [0, 2] },
          { text: (item.technologies || []).join(", "), italics: true, margin: [0, 2] }
        ],
        margin: [0, 0, 0, 10]
      }));
    default:
      return { text: JSON.stringify(section.content, null, 2) };
  }
}
var JWT_SECRET = process.env.JWT_SECRET;
var supabase = (0, import_supabase_js.createClient)(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);
function verifyJWT(req) {
  const authHeader = req.headers["authorization"] || req.headers["Authorization"];
  if (!authHeader)
    throw new Error("Authorization header is missing");
  const token = authHeader.split(" ")[1];
  if (!token)
    throw new Error("Token is missing");
  try {
    const payload = import_jsonwebtoken.default.verify(token, JWT_SECRET);
    if (!payload || !payload.sub)
      throw new Error("Invalid token payload");
    return payload.sub;
  } catch {
    throw new Error("Invalid token");
  }
}
async function validateInput(data) {
  if (!data.cv_id)
    throw new Error("cv_id is required");
  if (typeof data.cv_id !== "string")
    throw new Error("cv_id must be a string");
  return data.cv_id;
}
async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "authorization, x-client-info, apikey, content-type");
  if (req.method === "OPTIONS") {
    res.status(200).send("ok");
    return;
  }
  let status = 200;
  let response = {};
  try {
    const userId = verifyJWT(req);
    const data = req.body;
    const cv_id = await validateInput(data);
    const { data: cv, error: cvError } = await supabase.from("user_cvs").select("*,template:cv_templates(*),sections:cv_sections(*)").eq("id", cv_id).single();
    if (cvError) {
      console.error("Supabase Error:", cvError);
      throw new Error("Error while fetching the CV");
    }
    if (!cv) {
      console.error("CV not found:", cv_id);
      throw new Error("CV not found");
    }
    const templateStyle = getTemplateStyle(cv.template.category);
    const content = [];
    const headerSection = cv.sections.find((s) => s.type === "header" /* HEADER */);
    if (headerSection) {
      content.push({
        stack: [
          { text: headerSection.content.name, style: "header" },
          { text: headerSection.content.title, style: "subheader" },
          {
            columns: [
              { text: headerSection.content.email, style: "contact" },
              { text: headerSection.content.phone, style: "contact" },
              { text: headerSection.content.location, style: "contact" }
            ]
          }
        ],
        margin: [0, 0, 0, 20]
      });
    }
    cv.sections.forEach((section) => {
      if (section.type !== "header" /* HEADER */) {
        const sectionContent = getSectionContent(section);
        if (Array.isArray(sectionContent)) {
          content.push(...sectionContent);
        } else {
          content.push(sectionContent);
        }
      }
    });
    const docDefinition = {
      content,
      defaultStyle: { font: "Helvetica" },
      pageSize: "A4",
      pageMargins: [40, 60, 40, 60],
      info: { title: "CV" },
      styles: templateStyle.styles
    };
    const fonts = {
      Helvetica: {
        normal: "Helvetica",
        bold: "Helvetica-Bold",
        italics: "Helvetica-Oblique",
        bolditalics: "Helvetica-BoldOblique"
      }
    };
    const printer = new import_pdfmake.default(fonts);
    const pdfDoc = printer.createPdfKitDocument(docDefinition);
    const chunks = [];
    pdfDoc.on("data", (chunk) => chunks.push(chunk));
    pdfDoc.on("end", () => {
      const result = Buffer.concat(chunks);
      const pdfBase64 = result.toString("base64");
      response = { pdf: pdfBase64 };
      res.status(200).json(response);
    });
    pdfDoc.end();
    return;
  } catch (error) {
    console.error("Error generating PDF:", error);
    response = { error: error.message };
    if (error.message === "Authorization header is missing" || error.message === "Invalid token" || error.message === "Token is missing") {
      status = 401;
    } else {
      status = 400;
    }
    res.status(status).json(response);
    return;
  }
}
