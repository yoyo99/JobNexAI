"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// functions/analyze-cv/index.ts
var analyze_cv_exports = {};
__export(analyze_cv_exports, {
  default: () => handler
});
module.exports = __toCommonJS(analyze_cv_exports);
var import_openai = __toESM(require("openai"));
var import_supabase_js = require("@supabase/supabase-js");
var openai = new import_openai.default({
  apiKey: process.env.OPENAI_API_KEY
});
var supabase = (0, import_supabase_js.createClient)(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);
async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "authorization, x-client-info, apikey, content-type");
  if (req.method === "OPTIONS") {
    res.status(200).send("ok");
    return;
  }
  try {
    const { cv, jobDescription } = req.body;
    const prompt = `You are an expert CV analyst and career coach. Analyze the CV and provide detailed feedback.
          If a job description is provided, analyze the CV's relevance for that position.
          Focus on:
          1. Content completeness and clarity
          2. Professional experience presentation
          3. Skills relevance and presentation
          4. Overall impact and effectiveness
          5. ATS optimization
          Return a JSON object with:
          - score (0-100)
          - strengths (array of strings)
          - weaknesses (array of strings)
          - suggestions (array of objects with section, priority, and suggestion)
          CV: ${JSON.stringify(cv)}
          ${jobDescription ? `Job Description: ${jobDescription}` : ""}`;
    const completion = await openai.completions.create({
      model: "text-davinci-003",
      prompt,
      max_tokens: 300,
      temperature: 0.7
    });
    const analysis = JSON.parse(completion.choices[0].text ?? "{}");
    const { error: analysisError } = await supabase.from("cv_analysis").insert({
      cv_id: cv.id,
      analysis_type: jobDescription ? "job_match" : "general",
      score: analysis.score,
      details: analysis
    });
    if (analysisError)
      throw analysisError;
    const { error: suggestionsError } = await supabase.from("cv_improvements").insert(
      analysis.suggestions.map((suggestion) => ({
        cv_id: cv.id,
        section: suggestion.section,
        suggestion: suggestion.suggestion,
        priority: suggestion.priority
      }))
    );
    if (suggestionsError)
      throw suggestionsError;
    res.status(200).json(analysis);
    return;
  } catch (error) {
    console.error("Error analyzing CV:", error);
    res.status(400).json({ error: error.message });
    return;
  }
}
