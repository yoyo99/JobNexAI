"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// functions/job-matching/index.ts
var job_matching_exports = {};
__export(job_matching_exports, {
  default: () => handler
});
module.exports = __toCommonJS(job_matching_exports);
var import_config = require("dotenv/config");
var import_supabase_js = require("@supabase/supabase-js");
var import_openai = __toESM(require("openai"));
var import_jsonwebtoken = __toESM(require("jsonwebtoken"));
var import_uuid = require("uuid");
var openai = new import_openai.default({
  apiKey: process.env.OPENAI_API_KEY
});
var supabase = (0, import_supabase_js.createClient)(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);
var validateInput = (input) => {
  if (!input.userId || !input.jobId) {
    return "Missing userId or jobId";
  }
  if (!(0, import_uuid.validate)(input.userId)) {
    return "Invalid userId";
  }
  if (!(0, import_uuid.validate)(input.jobId)) {
    return "Invalid jobId";
  }
  return null;
};
var authenticate = async (req) => {
  const authHeader = req.headers.get("Authorization");
  if (!authHeader) {
    throw new Error("Unauthorized");
  }
  const token = authHeader.split(" ")[1];
  const secret = process.env.JWT_SECRET;
  try {
    import_jsonwebtoken.default.verify(token, secret);
    return token;
  } catch {
    throw new Error("Unauthorized");
  }
};
var getUserSkills = async (userId) => {
  const { data: userData, error: userError } = await supabase.from("user_skills").select(`
      skill:skills (
        name,
        category
      ),
      proficiency_level,
      years_experience
    `).eq("user_id", userId);
  if (userError) {
    throw new Error("Error fetching user data");
  }
  return userData;
};
var getJobData = async (jobId) => {
  const { data: jobData, error: jobError } = await supabase.from("jobs").select(`
      *,
      job_skills (
        skill:skills (
          name,
          category
        ),
        importance
      )
    `).eq("id", jobId).single();
  if (jobError) {
    throw new Error("Error fetching job data");
  }
  return jobData;
};
var transformUserSkills = (userData) => {
  return userData.map((skill) => ({
    name: skill.skill.name,
    category: skill.skill.category,
    proficiency: skill.proficiency_level,
    experience: skill.years_experience
  }));
};
var transformJobSkills = (jobData) => {
  return jobData.job_skills.map((skill) => ({
    name: skill.skill.name,
    category: skill.skill.category,
    importance: skill.importance
  }));
};
var analyzeJobMatch = async (jobData, userSkills, jobSkills) => {
  try {
    const completion = await openai.chat.completions.create({
      model: "gpt-4",
      messages: [
        {
          role: "system",
          content: `Tu es un expert en recrutement charg\xE9 d'\xE9valuer la correspondance entre un candidat et un poste.
          Analyse les comp\xE9tences du candidat et les exigences du poste pour calculer un score de correspondance et fournir des recommandations.
          Retourne un objet JSON avec :
          - score : pourcentage de correspondance (0-100)
          - matchingSkills : tableau des comp\xE9tences correspondantes
          - missingSkills : tableau des comp\xE9tences manquantes importantes
          - recommendations : suggestions pour am\xE9liorer la correspondance`
        },
        {
          role: "user",
          content: JSON.stringify({
            jobTitle: jobData.title ?? "",
            jobDescription: jobData.description ?? "",
            jobSkills: jobSkills ?? [],
            userSkills: userSkills ?? []
          })
        }
      ],
      temperature: 0.5
    });
    const content = completion.choices[0].message.content;
    if (!content)
      throw new Error("OpenAI did not return any content");
    return JSON.parse(content);
  } catch (openaiError) {
    throw new Error("Error with OpenAI");
  }
};
async function handler(req, res) {
  if (req.method === "OPTIONS") {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Headers", "authorization, x-client-info, apikey, content-type");
    return res.status(200).send("ok");
  }
  try {
    await authenticate(req);
    let { userId, jobId } = req.body || req.query || {};
    if (!userId || typeof userId !== "string") {
      return res.status(400).json({ error: "userId is required", code: 400 });
    }
    if (!jobId || typeof jobId !== "string") {
      return res.status(400).json({ error: "jobId is required", code: 400 });
    }
    const validationError = validateInput({ userId, jobId });
    if (validationError) {
      console.error("Validation error:", validationError);
      return res.status(400).json({ error: validationError, code: 400 });
    }
    const userIdStr = userId;
    const jobIdStr = jobId;
    const userSkills = await getUserSkills(userIdStr);
    const jobData = await getJobData(jobIdStr);
    const transformedUserSkills = transformUserSkills(userSkills);
    const jobSkills = transformJobSkills(jobData);
    const analysis = await analyzeJobMatch(jobData, userSkills, jobSkills);
    if (!analysis.score || !analysis.matchingSkills || !analysis.missingSkills || !analysis.recommendations) {
      throw new Error("Error during the analyse");
    }
    const { error: updateError } = await supabase.from("job_matches").upsert({
      user_id: userIdStr,
      job_id: jobIdStr,
      match_score: analysis.score,
      skills_match_percentage: jobSkills.length > 0 ? analysis.matchingSkills.length / jobSkills.length * 100 : 0,
      ai_analysis: analysis,
      updated_at: (/* @__PURE__ */ new Date()).toISOString()
    });
    if (updateError) {
      console.error("Supabase updateError:", updateError);
      return res.status(500).json({ error: "Error updating job match", code: 500 });
    }
    return res.status(200).json({ data: analysis });
  } catch (error) {
    console.error("Error:", error);
    return res.status(400).json({ error: "An unexpected error occurred", code: 500 });
  }
}
