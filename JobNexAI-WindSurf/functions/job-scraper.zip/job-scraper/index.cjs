"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// functions/job-scraper/index.ts
var job_scraper_exports = {};
__export(job_scraper_exports, {
  default: () => handler
});
module.exports = __toCommonJS(job_scraper_exports);
var import_supabase_js = require("@supabase/supabase-js");
var import_cheerio = require("cheerio");
var import_jsonwebtoken = __toESM(require("jsonwebtoken"));
var DEFAULT_LOCATION = "France";
var FULL_TIME_JOB_TYPE = "FULL_TIME";
var supabaseUrl = process.env.SUPABASE_URL;
var supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
var supabase = (0, import_supabase_js.createClient)(supabaseUrl, supabaseServiceKey);
var corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type"
};
var WEB_SCRAPING_HEADERS = {
  "Accept": "text/html",
  // Accept HTML content
  "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
  // Mimic a web browser
};
function validateToken(req) {
  const authHeader = req.headers["authorization"] || req.headers["Authorization"];
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    throw { error: "Missing Authorization header", code: 401 };
  }
  const token = authHeader.split(" ")[1];
  if (!token) {
    throw { error: "Missing token", code: 401 };
  }
  try {
    if (!process.env.JWT_SECRET) {
      throw new Error("JWT_SECRET environment variable is not defined.");
    }
    const payload = import_jsonwebtoken.default.verify(token, process.env.JWT_SECRET);
    if (!payload.userId)
      throw new Error("Invalid token payload");
    return payload.userId;
  } catch (err) {
    console.error("Token verification error:", err);
    throw { error: "Invalid token", code: 401 };
  }
}
async function checkAdmin(userId) {
  const { data, error } = await supabase.from("profiles").select("is_admin").eq("id", userId).single();
  if (error)
    throw error;
  if (!data?.is_admin) {
    throw { error: "Forbidden", code: 403 };
  }
}
function mapWTTJJobType(type) {
  const typeMap = {
    "full-time": "FULL_TIME",
    "part-time": "PART_TIME",
    "internship": "INTERNSHIP",
    "freelance": "FREELANCE",
    "apprenticeship": "INTERNSHIP"
  };
  return typeMap[type.toLowerCase()] || "FULL_TIME";
}
function mapWTTJJobData(job, sourceId) {
  return {
    source_id: sourceId,
    title: job.title,
    company: job.company.name,
    location: job.office.city || DEFAULT_LOCATION,
    description: job.description,
    job_type: mapWTTJJobType(job.contract_type),
    url: `https://www.welcometothejungle.com/fr/companies/${job.company.slug}/jobs/${job.slug}`,
    posted_at: job.published_at
  };
}
function mapLinkedInJobData(element, sourceId) {
  const $el = (0, import_cheerio.load)(element);
  const title = $el.find(".job-search-card__title").text().trim();
  const company = $el.find(".job-search-card__company-name").text().trim();
  const location = $el.find(".job-search-card__location").text().trim();
  const url = $el.find("a.job-search-card__link").attr("href") || "";
  const postedDate = $el.find("time").attr("datetime") || (/* @__PURE__ */ new Date()).toISOString();
  return {
    source_id: sourceId,
    title,
    company,
    location,
    description: "",
    job_type: FULL_TIME_JOB_TYPE,
    url,
    posted_at: postedDate
  };
}
function mapIndeedJobData(element, sourceId) {
  const $el = (0, import_cheerio.load)(element);
  const title = $el.find(".jobTitle").text().trim();
  const company = $el.find(".companyName").text().trim();
  const location = $el.find(".companyLocation").text().trim();
  const url = "https://fr.indeed.com" + ($el.find(".jobTitle a").attr("href") || "");
  return {
    source_id: sourceId,
    title,
    company,
    location,
    description: "",
    job_type: FULL_TIME_JOB_TYPE,
    url,
    posted_at: (/* @__PURE__ */ new Date()).toISOString()
  };
}
async function scrapeJobs(url, sourceId, mapJobData, selector) {
  try {
    const specificHeaders = url.includes("welcometothejungle") ? { "Accept": "application/json" } : WEB_SCRAPING_HEADERS;
    const response = await fetch(url, {
      headers: {
        ...specificHeaders
      }
    });
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    const data = url.includes("welcometothejungle") ? await response.json() : await response.text();
    if (typeof data === "string") {
      const $ = (0, import_cheerio.load)(data);
      const jobs = [];
      $(selector).each((_, element) => {
        jobs.push(mapJobData(element, sourceId));
      });
      return jobs;
    } else {
      return data.jobs.map((job) => mapJobData(job, sourceId));
    }
  } catch (error) {
    console.error(`Error scraping from ${url}:`, error);
    return [];
  }
}
var jobSources = {
  "welcome to the jungle": {
    url: "https://api.welcometothejungle.com/api/v1/jobs?page=1&per_page=30&query=developer&language=fr",
    mapData: mapWTTJJobData
  },
  "linkedin": {
    url: "https://www.linkedin.com/jobs-guest/jobs/api/seeMoreJobPostings/search?keywords=developer&location=France&start=0",
    mapData: mapLinkedInJobData,
    selector: ".job-search-card"
  },
  "indeed": {
    url: "https://fr.indeed.com/jobs?q=developer&l=France&sort=date",
    mapData: mapIndeedJobData,
    selector: ".job_seen_beacon"
  }
};
async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "authorization, x-client-info, apikey, content-type");
  if (req.method === "OPTIONS") {
    res.status(200).send("ok");
    return;
  }
  try {
    const userId = await validateToken(req);
    try {
      await checkAdmin(userId);
    } catch (adminError) {
      console.error("Admin check error:", adminError);
      return new Response(JSON.stringify({ error: "Forbidden", code: 403, details: adminError }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 403
      });
    }
    const { data: sources, error: sourcesError } = await supabase.from("job_sources").select("*").eq("is_active", true);
    if (sourcesError) {
      console.error("Supabase error fetching job sources:", sourcesError);
      const errorResponse = { error: "Failed to fetch job sources", code: 500, details: sourcesError };
      return new Response(JSON.stringify(errorResponse), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 500
      });
    }
    if (!sources?.length) {
      const errorResponse = { error: "No active job sources found", code: 404 };
      return new Response(JSON.stringify(errorResponse), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 404
      });
    }
    ;
    const allJobs = [];
    const errors = [];
    for (const source of sources || []) {
      try {
        const sourceParams = jobSources[source.name.toLowerCase()];
        const jobs = await scrapeJobs(sourceParams.url, source.id, sourceParams.mapData, sourceParams.selector);
        allJobs.push(...jobs);
      } catch (scrapeError) {
        console.error(`Error scraping from ${source.name}:`, scrapeError);
        errors.push({ source: source.name, error: scrapeError });
      }
    }
    ;
    if (allJobs.length > 0) {
      const { error: upsertError } = await supabase.from("jobs").upsert(allJobs, { onConflict: "url" });
      if (upsertError) {
        console.error("Supabase error inserting jobs:", upsertError);
        const errorResponse = { error: "Failed to insert jobs", code: 500, details: upsertError };
        return new Response(JSON.stringify(errorResponse), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
          status: 500
        });
      }
    }
    return new Response(
      JSON.stringify({
        message: "Jobs scraped successfully",
        count: allJobs.length,
        sources: (sources || []).map((s) => s.name),
        errors: errors.length > 0 ? errors : void 0
      }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 200
      }
    );
  } catch (error) {
    console.error("Unhandled error:", error);
    const errorResponse = { error: "Internal Server Error", code: 500, details: error };
    return new Response(
      JSON.stringify(errorResponse),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 500
      }
    );
  }
}
